# HWA ITIC 2026 Planner (hosted version)

Single-file web app. Data syncs through Firebase Firestore (project healthwatch-tpa), collections
`itic2026_assignments`, `itic2026_notes`, `itic2026_walkups`. Team PIN gate on first open (remembered per device).

## Publish on GitHub Pages
1. Create repo `medlinkint-hub/itic-2026`.
2. Upload `index.html`, `manifest.json`, `icon.png` to the repo root.
3. Settings → Pages → Deploy from branch → `main` / root → Save.
4. Live in ~1 minute at https://medlinkint-hub.github.io/itic-2026/

## On phones
Open the link → Share → "Add to Home Screen" (iPhone) or ⋮ → "Install app" (Android).

## Change the PIN
The PIN is stored as a SHA-256 hash of `hwa-itic-2026:<PIN>` in `PIN_HASH` inside index.html.
